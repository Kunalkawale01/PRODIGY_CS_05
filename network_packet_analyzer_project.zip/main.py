"""
Network Packet Analyzer (Educational & Consent-Based)
----------------------------------------------------
Captures and analyzes network packets for learning purposes.
Run ONLY on networks you own or have explicit permission to analyze.

Requires elevated privileges.
"""

from scapy.all import sniff, IP, TCP, UDP
from datetime import datetime

LOG_FILE = "packets.log"

def analyze_packet(packet):
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if IP in packet:
        src = packet[IP].src
        dst = packet[IP].dst
        proto = packet[IP].proto

        protocol_name = "OTHER"
        payload = ""

        if TCP in packet:
            protocol_name = "TCP"
            payload = bytes(packet[TCP].payload)[:64]
        elif UDP in packet:
            protocol_name = "UDP"
            payload = bytes(packet[UDP].payload)[:64]

        with open(LOG_FILE, "a") as f:
            f.write(f"[{timestamp}] {protocol_name} | {src} -> {dst} | Payload: {payload}\n")

        print(f"[{timestamp}] {protocol_name} | {src} -> {dst}")

def start_sniffing():
    print("Network Packet Analyzer Started")
    print("Press CTRL+C to stop")
    sniff(prn=analyze_packet, store=False)

if __name__ == "__main__":
    start_sniffing()
