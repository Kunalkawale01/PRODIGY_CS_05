# Network Packet Analyzer

## 📌 Project Overview
This project is a **basic network packet analyzer** developed for **educational and cybersecurity learning purposes**.
It captures live network packets and extracts important information such as IP addresses, protocol types, and payload samples.

---

## ⚠ Ethical & Legal Disclaimer
This tool must be used **ONLY**:
- On networks you own
- On networks where you have **explicit permission**

Unauthorized packet sniffing is illegal and unethical.
The author is not responsible for misuse.

---

## 🛠 Features
- Captures live network traffic
- Identifies source & destination IP addresses
- Detects TCP and UDP protocols
- Logs packet payload (limited bytes for safety)
- Saves analysis to `packets.log`

---

## 📂 Project Structure
```
network_packet_analyzer/
│── main.py
│── README.md
│── requirements.txt
```

---

## ⚙ Requirements
- Python 3.x
- scapy library
- Administrator / Root privileges

Install dependencies:
```bash
pip install -r requirements.txt
```

---

## ▶ How to Run

### Linux / macOS
```bash
sudo python main.py
```

### Windows (Run as Administrator)
```bash
python main.py
```

---

## ⛔ Stop Capture
Press **CTRL + C**

---

## 🧪 Output
Captured packets are saved to:
```
packets.log
```

Each entry includes:
- Timestamp
- Protocol
- Source IP
- Destination IP
- Payload snippet

---

## 🎓 Learning Outcomes
- Understanding packet structures
- TCP/IP protocol analysis
- Network traffic monitoring basics
- Ethical cybersecurity practices

---

## 📜 License
Educational use only. Commercial or malicious use is prohibited.
